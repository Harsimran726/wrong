from itertools import count
from unicodedata import name
from django.contrib import admin
from django.urls import path, include


from countap import views 
from django.conf.urls.static import static

urlpatterns = [ 
	path("counter", views.counter, name='counter'),
    path("", views.index, name='home'),
    
]
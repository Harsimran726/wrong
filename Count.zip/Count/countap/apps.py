from django.apps import AppConfig


class CountapConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'countap'
